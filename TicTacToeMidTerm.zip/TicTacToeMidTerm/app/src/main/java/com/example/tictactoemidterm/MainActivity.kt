package com.example.tictactoemidterm

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.content.Intent
import android.widget.Button
import android.widget.EditText
import android.widget.TextView


class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val enterNameButton:Button = findViewById(R.id.enterName)

        enterNameButton.setOnClickListener {
            val userName: EditText = findViewById(R.id.PersonName)
            //val realName = userName.text.toString()
            val fakeName = "Friend"
            val intent = Intent(this, secondScreen::class.java)
            if (!userName.text.toString().isEmpty())
                {
                    val realName = userName.text.toString()
                    intent.putExtra("realName", realName)
                }
            else
                {
                    intent.putExtra("realName", fakeName)
                }
            startActivity(intent)
        }
        }
    }

