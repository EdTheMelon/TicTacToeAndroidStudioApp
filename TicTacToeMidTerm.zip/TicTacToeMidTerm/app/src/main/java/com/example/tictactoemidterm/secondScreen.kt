package com.example.tictactoemidterm

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.content.Intent

class secondScreen : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_second_screen)
        val userName = intent.getStringExtra("realName").toString()
        //val userName:EditText = findViewById(R.id.PersonName)
        val helloMessage:TextView = findViewById(R.id.helloText)
        helloMessage.setText("Hello, ${userName}!")


        val BackButton: Button = findViewById(R.id.btn_go_back)
        BackButton.setOnClickListener{
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }

        val PvP: Button = findViewById(R.id.btn_pvp)
        PvP.setOnClickListener{
            val intent = Intent(this, gameActivity::class.java)
            intent.putExtra("computerPlays", false)
            startActivity(intent)
        }
        val PvC: Button = findViewById(R.id.btn_pvc)
        PvC.setOnClickListener{
            val intent = Intent(this, gameActivity::class.java)
            intent.putExtra("computerPlays", true)
            startActivity(intent)
        }

    }
}