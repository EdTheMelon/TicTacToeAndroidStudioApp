package com.example.tictactoemidterm

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import kotlin.random.Random


var moveList = 0
var gameScoreX = 0
var gameScoreY = 0
class gameActivity : AppCompatActivity() {



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_game)

        moveList = 0
        gameScoreX = 0
        gameScoreY = 0

        val computerPlays = intent.getBooleanExtra("computerPlays", false)


        val gameScoreTextX: TextView = findViewById(R.id.GameScoreX)
        val gameScoreTextY: TextView = findViewById(R.id.GameScoreY)
        val btn_11: Button = findViewById(R.id.bt_11)
        val btn_12: Button = findViewById(R.id.bt_12)
        val btn_13: Button = findViewById(R.id.bt_13)
        val btn_21: Button = findViewById(R.id.bt_21)
        val btn_22: Button = findViewById(R.id.bt_22)
        val btn_23: Button = findViewById(R.id.bt_23)
        val btn_31: Button = findViewById(R.id.bt_31)
        val btn_32: Button = findViewById(R.id.bt_32)
        val btn_33: Button = findViewById(R.id.bt_33)
        val newGameButton: Button = findViewById(R.id.newGameButton)
        val backButton: Button = findViewById(R.id.gameGoBack)

        val scoreTextView: TextView = findViewById(R.id.gameWinDialog)
        if (!computerPlays){
            scoreTextView.setText(" ")
        }

        val butArray = arrayOf(btn_11, btn_12, btn_13, btn_21, btn_22, btn_23, btn_31, btn_32, btn_33)



        gameScoreTextX.setText("X - $gameScoreX")
        gameScoreTextY.setText("O - $gameScoreY")

        btn_11.setOnClickListener {
            if (checkTextEmpty(btn_11)) {
                changeButton(btn_11, butArray, computerPlays)
            }
        }
        btn_12.setOnClickListener {
            if (checkTextEmpty(btn_12)) {
                changeButton(btn_12, butArray, computerPlays)
            }
        }
        btn_13.setOnClickListener {
            if (checkTextEmpty(btn_13)) {
                changeButton(btn_13, butArray,computerPlays)
            }
        }
        btn_21.setOnClickListener {
            if (checkTextEmpty(btn_21)) {
                changeButton(btn_21, butArray,computerPlays)
            }
        }
        btn_22.setOnClickListener {
            if (checkTextEmpty(btn_22)) {
                changeButton(btn_22, butArray,computerPlays)
            }
        }
        btn_23.setOnClickListener {
            if (checkTextEmpty(btn_23)) {
                changeButton(btn_23, butArray,computerPlays)
            }
        }
        btn_31.setOnClickListener {
            if (checkTextEmpty(btn_31)) {
                changeButton(btn_31, butArray,computerPlays)
            }
        }
        btn_32.setOnClickListener {
            if (checkTextEmpty(btn_32)) {
                changeButton(btn_32, butArray,computerPlays)
            }
        }
        btn_33.setOnClickListener {
            if (checkTextEmpty(btn_33)) {
                changeButton(btn_33, butArray,computerPlays)
            }
        }
        newGameButton.setOnClickListener {
            for (btn in butArray){
                btn.setText(" ")
            }
            moveList = 0
            val textBox: TextView = findViewById(R.id.gameWinDialog)
            textBox.setText(" ")
        }

        backButton.setOnClickListener {
            val intent = Intent(this, secondScreen::class.java)
            intent.putExtra("realName", "friend")
            startActivity(intent)
        }



    }

    fun checkTextEmpty(btn: Button?): Boolean {
        val btn_text = btn?.text.toString()
        return btn_text.equals(" ")
    }
    //This is the reason why the player v computer gameplay has different rules.
    //To make the game more challe
    fun randMove(butArray: Array<Button>): Button {
        val emptyCells = mutableListOf<Button>()
        emptyCells.clear()
        for (but in butArray){
            if(checkTextEmpty(but))
                emptyCells.add(but)
        }
        val randomNumber = Random.nextInt(0,emptyCells.count() )
        return emptyCells[randomNumber]
    }

    fun moreMovesPossible(butArray: Array<Button>): Boolean{
        for (but in butArray){
            if (but.text.toString().equals(" "))
                return true
        }
        return false
    }

    fun checkSameSymbol(btn1: Button, btn2:Button, btn3:Button): Boolean{
        val bt1_text = btn1.text.toString()
        val bt2_text = btn2.text.toString()
        val bt3_text = btn3.text.toString()
        return (bt1_text.equals(bt2_text) && bt1_text.equals(bt3_text) && !bt1_text.equals(" "))
    }
    fun checkWin(butArray: Array<Button>): Boolean{
        print("done")
        return (checkSameSymbol(butArray[0], butArray[1], butArray[2]) ||
                checkSameSymbol(butArray[3], butArray[4], butArray[5]) ||
                checkSameSymbol(butArray[6], butArray[7], butArray[8]) ||
                checkSameSymbol(butArray[0], butArray[3], butArray[6]) ||
                checkSameSymbol(butArray[1], butArray[4], butArray[7]) ||
                checkSameSymbol(butArray[2], butArray[5], butArray[8]) ||
                checkSameSymbol(butArray[0], butArray[4], butArray[8]) ||
                checkSameSymbol(butArray[6], butArray[4], butArray[2]) )
    }


    fun changeButton(btn: Button?, butArray: Array<Button>, computerPlays: Boolean) {
        if (checkWin(butArray)){
            return
        }
        val symbol: String
        if (moveList % 2 == 0)
            symbol = "X"
        else
            symbol = "O"
        btn?.setText(symbol)
        if (!checkWin(butArray)) {
            moveList += 1
            if (computerPlays && moveList % 2 == 1 && moreMovesPossible(butArray)) {
                val nextButton = randMove(butArray)
                changeButton(nextButton, butArray, computerPlays)
            }
            if (!moreMovesPossible(butArray)){
                val textBox: TextView = findViewById(R.id.gameWinDialog)
                if (computerPlays){
                    gameScoreX += 1
                    textBox.setText("Game Won by the Player")
                    val scoreText: TextView = findViewById(R.id.GameScoreX)
                    scoreText.setText("X - ${gameScoreX}")
                }
                else{
                    textBox.setText("Game ended in a tie")
                }
            }
        }
        else if (!computerPlays) { //kas notiek, kad spele beidzas, kad dators spele. Izmanto gajienu skaitu
            val textBox: TextView = findViewById(R.id.gameWinDialog)
            if (moveList % 2 == 0) {
                gameScoreX += 1
                textBox.setText("Game Won by Player X")
                val scoreText: TextView = findViewById(R.id.GameScoreX)
                scoreText.setText("X - ${gameScoreX}")
            }
            else {
                gameScoreY += 1
                textBox.setText("Game Won by Player O")
                val scoreText: TextView = findViewById(R.id.GameScoreY)
                scoreText.setText("${gameScoreY} - O")
            }
        }
        else if (computerPlays){
            val textBox: TextView = findViewById(R.id.gameWinDialog)
                gameScoreY += 1
                textBox.setText("Game Won by the Computer")
                val scoreText: TextView = findViewById(R.id.GameScoreY)
                scoreText.setText("O - ${gameScoreY}")
        }

    }
}